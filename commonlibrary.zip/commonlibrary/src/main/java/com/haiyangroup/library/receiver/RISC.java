package com.haiyangroup.library.receiver;

/**
 * Created by leo on 2015/7/30.
 */
public class RISC {
    public static final int TEST = 0x0001;
}
