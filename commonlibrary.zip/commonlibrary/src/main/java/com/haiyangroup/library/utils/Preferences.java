package com.haiyangroup.library.utils;

public class Preferences {
    public static final String OUTPUT_LOGFILE = "outputLogFile";
    public static final String ENABLE_NIGHT_MODE = "enableNightMode";
}